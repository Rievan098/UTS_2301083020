import 'package:flutter/material.dart';
import 'transaksi.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Warnet App',
      initialRoute: '/',
      routes: {
        '/': (context) => HomePage(),
        '/transaksi': (context) => TransaksiPage(),
      },
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      drawer: Drawer(
        child: Container(
          color: Colors.blueAccent, // Change background color
          child: ListView(
            children: <Widget>[
              DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.blue, // Header background color
                ),
                child: Text(
                  'Menu Drawer',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              ListTile(
                leading: Icon(Icons.computer, color: Colors.white), // Icon color
                title: Text(
                  'Transaksi Warnet',
                  style: TextStyle(color: Colors.white), // Text color
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/transaksi');
                },
              ),
              Divider(color: Colors.white), // Divider color
              ListTile(
                leading: Icon(Icons.info, color: Colors.white), // Icon color
                title: Text(
                  'About Us',
                  style: TextStyle(color: Colors.white), // Text color
                ),
                onTap: () {
                  // Add action for About Us
                },
              ),
            ],
          ),
        ),
      ),
      body: Center(
        child: Text('Selamat Datang di Van Warnet'),
      ),
    );
  }
}
