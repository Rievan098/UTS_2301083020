import 'package:flutter/material.dart';

class Warnet {
  final String kodeTransaksi;
  final String namaPelanggan;
  final String jenisPelanggan; // 'VIP' or 'GOLD'
  final DateTime tglMasuk;
  final DateTime jamMasuk;
  final DateTime jamKeluar;
  final double tarif;

  Warnet({
    required this.kodeTransaksi,
    required this.namaPelanggan,
    required this.jenisPelanggan,
    required this.tglMasuk,
    required this.jamMasuk,
    required this.jamKeluar,
    required this.tarif,
  });

  double get lama {
    return jamKeluar.difference(jamMasuk).inHours.toDouble();
  }

  double get diskon {
    if (lama > 2) {
      if (jenisPelanggan == 'VIP') {
        return 0.02 * (lama * tarif);
      } else if (jenisPelanggan == 'GOLD') {
        return 0.05 * (lama * tarif);
      }
    }
    return 0.0;
  }

  double get totalBayar {
    return (lama * tarif) - diskon;
  }
}

class TransaksiPage extends StatefulWidget {
  @override
  _TransaksiPageState createState() => _TransaksiPageState();
}

class _TransaksiPageState extends State<TransaksiPage> {
  final _kodeTransaksiController = TextEditingController();
  final _namaPelangganController = TextEditingController();
  final _jenisPelangganController = TextEditingController();
  final _tarifController = TextEditingController();
  DateTime _jamMasuk = DateTime.now();
  DateTime _jamKeluar = DateTime.now();

  Future<void> _selectJamMasuk(BuildContext context) async {
    TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        _jamMasuk = DateTime(
          _jamMasuk.year,
          _jamMasuk.month,
          _jamMasuk.day,
          picked.hour,
          picked.minute,
        );
      });
    }
  }

  Future<void> _selectJamKeluar(BuildContext context) async {
    TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        _jamKeluar = DateTime(
          _jamKeluar.year,
          _jamKeluar.month,
          _jamKeluar.day,
          picked.hour,
          picked.minute,
        );
      });
    }
  }

  void _calculateAndShowResult() {
    final String kodeTransaksi = _kodeTransaksiController.text;
    final String namaPelanggan = _namaPelangganController.text;
    final String jenisPelanggan = _jenisPelangganController.text;
    final double tarif = double.tryParse(_tarifController.text) ?? 0;

    Warnet transaksi = Warnet(
      kodeTransaksi: kodeTransaksi,
      namaPelanggan: namaPelanggan,
      jenisPelanggan: jenisPelanggan,
      tglMasuk: DateTime.now(),
      jamMasuk: _jamMasuk,
      jamKeluar: _jamKeluar,
      tarif: tarif,
    );

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Detail Transaksi'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Kode Transaksi: ${transaksi.kodeTransaksi}'),
              Text('Nama Pelanggan: ${transaksi.namaPelanggan}'),
              Text('Jenis Pelanggan: ${transaksi.jenisPelanggan}'),
              Text('Jam Masuk: ${transaksi.jamMasuk.hour}:${transaksi.jamMasuk.minute.toString().padLeft(2, '0')}'),
              Text('Jam Keluar: ${transaksi.jamKeluar.hour}:${transaksi.jamKeluar.minute.toString().padLeft(2, '0')}'),
              Text('Lama: ${transaksi.lama} Jam'),
              Text('Tarif: Rp ${transaksi.tarif}'),
              Text('Diskon: Rp ${transaksi.diskon.toStringAsFixed(2)}'),
              Text('Total Bayar: Rp ${transaksi.totalBayar.toStringAsFixed(2)}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Detail Transaksi Warnet')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _kodeTransaksiController,
              decoration: InputDecoration(labelText: 'Kode Transaksi'),
            ),
            TextField(
              controller: _namaPelangganController,
              decoration: InputDecoration(labelText: 'Nama Pelanggan'),
            ),
            TextField(
              controller: _jenisPelangganController,
              decoration: InputDecoration(labelText: 'Jenis Pelanggan (VIP/GOLD)'),
            ),
            TextField(
              controller: _tarifController,
              decoration: InputDecoration(labelText: 'Tarif'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            Text("Jam Masuk: ${_jamMasuk.hour}:${_jamMasuk.minute.toString().padLeft(2, '0')}"),
            ElevatedButton(
              onPressed: () => _selectJamMasuk(context),
              child: Text('Pilih Jam Masuk'),
            ),
            SizedBox(height: 20),
            Text("Jam Keluar: ${_jamKeluar.hour}:${_jamKeluar.minute.toString().padLeft(2, '0')}"),
            ElevatedButton(
              onPressed: () => _selectJamKeluar(context),
              child: Text('Pilih Jam Keluar'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _calculateAndShowResult,
              child: Text('Hitung Transaksi'),
            ),
          ],
        ),
      ),
    );
  }
}
