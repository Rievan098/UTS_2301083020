class Pelanggan {
  final String kode; // Unique code for the customer
  final String nama; // Name of the customer

  Pelanggan({
    required this.kode,
    required this.nama,
  });

  @override
  String toString() {
    return 'Pelanggan(kode: $kode, nama: $nama)';
  }
}
